class TorrentExtractor {
    constructor() {
        this.currentTheme = 'light';
        this.currentData = null;
        this.visibleFiles = 10;
        this.allFiles = [];
        this.filteredFiles = [];
        
        this.initializeApp();
    }

    initializeApp() {
        this.setupEventListeners();
        this.setupTheme();
        this.setupTabSwitching();
        this.setupFileUpload();
        this.setupValidation();
    }

    // Event Listeners Setup
    setupEventListeners() {
        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            this.toggleTheme();
        });

        // Extract button
        document.getElementById('extractBtn').addEventListener('click', () => {
            this.handleExtraction();
        });

        // Action buttons
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.downloadJSON();
        });

        document.getElementById('clearBtn').addEventListener('click', () => {
            this.clearResults();
        });

        // File search
        document.getElementById('fileSearchInput').addEventListener('input', (e) => {
            this.filterFiles(e.target.value);
        });
    }

    // Theme Management
    setupTheme() {
        document.documentElement.setAttribute('data-theme', this.currentTheme);
    }

    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', this.currentTheme);
    }

    // Tab Switching
    setupTabSwitching() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabPanels = document.querySelectorAll('.tab-panel');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabId = button.getAttribute('data-tab');
                
                // Update active states
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanels.forEach(panel => panel.classList.remove('active'));
                
                button.classList.add('active');
                document.getElementById(`${tabId}-tab`).classList.add('active');
                
                // Reset validation state
                this.validateInput();
            });
        });
    }

    // File Upload Setup
    setupFileUpload() {
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');

        // Click to browse
        uploadZone.addEventListener('click', () => {
            fileInput.click();
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                this.handleFileSelect(file);
            }
        });

        // Drag and drop
        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('dragover');
        });

        uploadZone.addEventListener('dragleave', () => {
            uploadZone.classList.remove('dragover');
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileSelect(files[0]);
            }
        });
    }

    // Input Validation
    setupValidation() {
        // Magnet URI input
        document.getElementById('magnetInput').addEventListener('input', (e) => {
            this.updateCharCounter(e.target.value.length);
            this.validateInput();
        });

        // Hash input
        document.getElementById('hashInput').addEventListener('input', (e) => {
            this.validateHash(e.target.value);
            this.validateInput();
        });
    }

    handleFileSelect(file) {
        if (!file.name.endsWith('.torrent')) {
            this.showToast('Please select a .torrent file', 'error');
            return;
        }

        const fileInfo = document.getElementById('fileInfo');
        const fileName = fileInfo.querySelector('.file-name');
        const fileSize = fileInfo.querySelector('.file-size');
        
        fileName.textContent = file.name;
        fileSize.textContent = this.formatBytes(file.size);
        fileInfo.style.display = 'flex';
        
        this.validateInput();
    }

    updateCharCounter(length) {
        document.getElementById('magnetCounter').textContent = `${length} characters`;
    }

    validateHash(hash) {
        const validation = document.getElementById('hashValidation');
        const isValid = /^[a-fA-F0-9]{40}$/.test(hash);
        
        if (hash.length === 0) {
            validation.className = 'validation-indicator';
        } else if (isValid) {
            validation.className = 'validation-indicator valid';
        } else {
            validation.className = 'validation-indicator invalid';
        }
    }

    validateInput() {
        const extractBtn = document.getElementById('extractBtn');
        const activeTab = document.querySelector('.tab-button.active').getAttribute('data-tab');
        let isValid = false;

        switch (activeTab) {
            case 'file':
                const fileInput = document.getElementById('fileInput');
                isValid = fileInput.files.length > 0;
                break;
            case 'magnet':
                const magnetInput = document.getElementById('magnetInput').value.trim();
                isValid = magnetInput.startsWith('magnet:') && magnetInput.includes('xt=urn:btih:');
                break;
            case 'hash':
                const hashInput = document.getElementById('hashInput').value.trim();
                isValid = /^[a-fA-F0-9]{40}$/.test(hashInput);
                break;
        }

        extractBtn.disabled = !isValid;
    }

    // Main Extraction Handler
    async handleExtraction() {
        const extractBtn = document.getElementById('extractBtn');
        const btnText = extractBtn.querySelector('.btn-text');
        const loadingSpinner = extractBtn.querySelector('.loading-spinner');
        
        // Show loading state
        btnText.style.display = 'none';
        loadingSpinner.style.display = 'flex';
        extractBtn.disabled = true;

        try {
            const activeTab = document.querySelector('.tab-button.active').getAttribute('data-tab');
            let data = null;

            switch (activeTab) {
                case 'file':
                    data = await this.extractFromFile();
                    break;
                case 'magnet':
                    data = await this.extractFromMagnet();
                    break;
                case 'hash':
                    data = await this.extractFromHash();
                    break;
            }

            if (data) {
                this.currentData = data;
                this.displayResults(data);
                this.showToast('Metadata extracted successfully!', 'success');
            }
        } catch (error) {
            console.error('Extraction error:', error);
            this.showToast(`Error: ${error.message}`, 'error');
        } finally {
            // Reset button state
            btnText.style.display = 'block';
            loadingSpinner.style.display = 'none';
            this.validateInput();
        }
    }

    async extractFromFile() {
        const fileInput = document.getElementById('fileInput');
        const file = fileInput.files[0];
        
        if (!file) throw new Error('No file selected');

        const arrayBuffer = await this.readFileAsArrayBuffer(file);
        const uint8Array = new Uint8Array(arrayBuffer);
        const decoded = this.bencodeDecode(uint8Array);
        
        return this.processTorrentData(decoded);
    }

    async extractFromMagnet() {
        const magnetUri = document.getElementById('magnetInput').value.trim();
        
        if (!magnetUri) throw new Error('No magnet URI provided');
        
        return this.parseMagnetUri(magnetUri);
    }

    async extractFromHash() {
        const hash = document.getElementById('hashInput').value.trim();
        
        if (!hash) throw new Error('No info hash provided');
        
        return {
            type: 'hash',
            name: 'Unknown',
            infoHash: hash.toLowerCase(),
            totalSize: 'Unknown',
            creationDate: 'Unknown',
            createdBy: 'Unknown',
            comment: 'Info hash only - upload .torrent file for complete metadata',
            files: [],
            trackers: [],
            pieceLength: 'Unknown',
            pieces: 'Unknown'
        };
    }

    // File Reading
    readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsArrayBuffer(file);
        });
    }

    // Bencode Decoder
    bencodeDecode(data) {
        let index = 0;

        const decode = () => {
            if (index >= data.length) {
                throw new Error('Unexpected end of data');
            }

            const char = String.fromCharCode(data[index]);

            if (char >= '0' && char <= '9') {
                // String
                return this.decodeString();
            } else if (char === 'i') {
                // Integer
                return this.decodeInteger();
            } else if (char === 'l') {
                // List
                return this.decodeList();
            } else if (char === 'd') {
                // Dictionary
                return this.decodeDictionary();
            } else {
                throw new Error(`Invalid bencode character: ${char}`);
            }
        };

        const decodeString = () => {
            let lengthStr = '';
            while (index < data.length && data[index] !== 58) { // 58 is ':'
                lengthStr += String.fromCharCode(data[index]);
                index++;
            }
            
            if (index >= data.length) {
                throw new Error('Invalid string format');
            }
            
            index++; // skip ':'
            const length = parseInt(lengthStr);
            
            if (isNaN(length) || length < 0) {
                throw new Error('Invalid string length');
            }
            
            const result = data.slice(index, index + length);
            index += length;
            
            // Try to decode as UTF-8, fall back to binary
            try {
                return new TextDecoder('utf-8').decode(result);
            } catch {
                return result;
            }
        };

        const decodeInteger = () => {
            index++; // skip 'i'
            let intStr = '';
            while (index < data.length && data[index] !== 101) { // 101 is 'e'
                intStr += String.fromCharCode(data[index]);
                index++;
            }
            
            if (index >= data.length) {
                throw new Error('Invalid integer format');
            }
            
            index++; // skip 'e'
            return parseInt(intStr);
        };

        const decodeList = () => {
            index++; // skip 'l'
            const list = [];
            
            while (index < data.length && data[index] !== 101) { // 101 is 'e'
                list.push(decode());
            }
            
            if (index >= data.length) {
                throw new Error('Invalid list format');
            }
            
            index++; // skip 'e'
            return list;
        };

        const decodeDictionary = () => {
            index++; // skip 'd'
            const dict = {};
            
            while (index < data.length && data[index] !== 101) { // 101 is 'e'
                const key = decode();
                if (typeof key !== 'string') {
                    throw new Error('Dictionary key must be a string');
                }
                const value = decode();
                dict[key] = value;
            }
            
            if (index >= data.length) {
                throw new Error('Invalid dictionary format');
            }
            
            index++; // skip 'e'
            return dict;
        };

        this.decodeString = decodeString;
        this.decodeInteger = decodeInteger;
        this.decodeList = decodeList;
        this.decodeDictionary = decodeDictionary;

        return decode();
    }

    // Process Torrent Data
    processTorrentData(decoded) {
        const info = decoded.info;
        if (!info) throw new Error('Invalid torrent file: missing info section');

        // Calculate info hash
        const infoHash = this.calculateInfoHash(info);
        
        // Extract file information
        let files = [];
        let totalSize = 0;

        if (info.files) {
            // Multi-file torrent
            files = info.files.map(file => {
                const size = file.length || 0;
                totalSize += size;
                return {
                    path: file.path.join('/'),
                    size: size,
                    sizeFormatted: this.formatBytes(size)
                };
            });
        } else {
            // Single-file torrent
            const size = info.length || 0;
            totalSize = size;
            files = [{
                path: info.name || 'unknown',
                size: size,
                sizeFormatted: this.formatBytes(size)
            }];
        }

        // Extract trackers
        let trackers = [];
        if (decoded.announce) {
            trackers.push(decoded.announce);
        }
        if (decoded['announce-list']) {
            for (const tier of decoded['announce-list']) {
                if (Array.isArray(tier)) {
                    trackers.push(...tier);
                } else {
                    trackers.push(tier);
                }
            }
        }
        // Remove duplicates
        trackers = [...new Set(trackers)];

        return {
            type: 'torrent',
            name: info.name || 'Unknown',
            infoHash: infoHash,
            totalSize: this.formatBytes(totalSize),
            totalSizeBytes: totalSize,
            creationDate: decoded['creation date'] ? new Date(decoded['creation date'] * 1000).toLocaleString() : 'Unknown',
            createdBy: decoded['created by'] || 'Unknown',
            comment: decoded.comment || 'No comment',
            private: info.private === 1,
            files: files,
            trackers: trackers,
            pieceLength: this.formatBytes(info['piece length'] || 0),
            pieceLengthBytes: info['piece length'] || 0,
            pieces: info.pieces ? `${Math.floor(info.pieces.length / 20)} pieces` : 'Unknown'
        };
    }

    // Calculate Info Hash
    calculateInfoHash(info) {
        // This is a simplified version - in a real implementation,
        // you would need to properly encode the info dictionary and hash it
        // For now, we'll generate a placeholder
        const str = JSON.stringify(info);
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash).toString(16).padStart(40, '0').substring(0, 40);
    }

    // Parse Magnet URI
    parseMagnetUri(magnetUri) {
        const url = new URL(magnetUri);
        const params = url.searchParams;
        
        let infoHash = '';
        const xt = params.get('xt');
        if (xt && xt.startsWith('urn:btih:')) {
            infoHash = xt.substring(9).toLowerCase();
        }
        
        const displayName = params.get('dn') || 'Unknown';
        const trackers = params.getAll('tr');
        
        return {
            type: 'magnet',
            name: decodeURIComponent(displayName),
            infoHash: infoHash,
            totalSize: 'Unknown',
            creationDate: 'Unknown',
            createdBy: 'Unknown',
            comment: 'Magnet URI - upload .torrent file for complete metadata',
            private: false,
            files: [],
            trackers: trackers,
            pieceLength: 'Unknown',
            pieces: 'Unknown',
            magnetUri: magnetUri
        };
    }

    // Display Results
    displayResults(data) {
        this.renderOverview(data);
        this.renderFiles(data.files);
        this.renderTrackers(data.trackers);
        this.renderTechnicalDetails(data);
        
        document.getElementById('resultsSection').style.display = 'block';
        document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth' });
    }

    renderOverview(data) {
        const content = document.getElementById('overviewContent');
        const items = [
            { label: 'Name', value: data.name },
            { label: 'Info Hash', value: data.infoHash, mono: true, copyable: true },
            { label: 'Total Size', value: data.totalSize },
            { label: 'Creation Date', value: data.creationDate },
            { label: 'Created By', value: data.createdBy },
            { label: 'Comment', value: data.comment },
            { label: 'Private', value: data.private ? 'Yes' : 'No' }
        ];

        if (data.magnetUri) {
            items.splice(2, 0, { label: 'Magnet URI', value: data.magnetUri, mono: true, copyable: true });
        }

        content.innerHTML = items.map(item => `
            <div class="overview-item">
                <div class="overview-label">${item.label}:</div>
                <div class="overview-value ${item.mono ? 'mono' : ''}">
                    ${item.value}
                    ${item.copyable ? `<button class="copy-btn" onclick="torrentExtractor.copyToClipboard('${item.value}')"><svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/><path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/></svg></button>` : ''}
                </div>
            </div>
        `).join('');
    }

    renderFiles(files) {
        this.allFiles = files;
        this.filteredFiles = files;
        this.visibleFiles = 10;
        
        const fileCount = document.getElementById('fileCount');
        const fileSearch = document.getElementById('fileSearch');
        const fileList = document.getElementById('fileList');
        
        fileCount.textContent = `${files.length} files`;
        
        if (files.length > 20) {
            fileSearch.style.display = 'block';
        }
        
        this.updateFileList();
    }

    updateFileList() {
        const fileList = document.getElementById('fileList');
        const filesToShow = this.filteredFiles.slice(0, this.visibleFiles);
        
        if (this.filteredFiles.length === 0) {
            fileList.innerHTML = '<div style="padding: 1rem; text-align: center; color: var(--text-muted);">No files found</div>';
            return;
        }
        
        let html = filesToShow.map(file => `
            <div class="file-item">
                <div class="file-name">${file.path}</div>
                <div class="file-size">${file.sizeFormatted}</div>
            </div>
        `).join('');
        
        if (this.filteredFiles.length > this.visibleFiles) {
            html += `
                <button class="show-more-btn" onclick="torrentExtractor.showMoreFiles()">
                    Show ${Math.min(10, this.filteredFiles.length - this.visibleFiles)} more files
                </button>
            `;
        }
        
        fileList.innerHTML = html;
    }

    showMoreFiles() {
        this.visibleFiles += 10;
        this.updateFileList();
    }

    filterFiles(query) {
        if (!query.trim()) {
            this.filteredFiles = this.allFiles;
        } else {
            this.filteredFiles = this.allFiles.filter(file => 
                file.path.toLowerCase().includes(query.toLowerCase())
            );
        }
        this.visibleFiles = 10;
        this.updateFileList();
    }

    renderTrackers(trackers) {
        const trackerCount = document.getElementById('trackerCount');
        const trackersContent = document.getElementById('trackersContent');
        
        trackerCount.textContent = `${trackers.length} trackers`;
        
        if (trackers.length === 0) {
            trackersContent.innerHTML = '<div style="padding: 1rem; text-align: center; color: var(--text-muted);">No trackers found</div>';
            return;
        }
        
        trackersContent.innerHTML = `
            <div class="tracker-list">
                ${trackers.map(tracker => `
                    <div class="tracker-item">${tracker}</div>
                `).join('')}
            </div>
        `;
    }

    renderTechnicalDetails(data) {
        const content = document.getElementById('technicalContent');
        const items = [
            { label: 'Piece Length', value: data.pieceLength },
            { label: 'Pieces', value: data.pieces },
            { label: 'Protocol', value: 'BitTorrent v1' },
            { label: 'Hash Algorithm', value: 'SHA-1' }
        ];

        content.innerHTML = items.map(item => `
            <div class="tech-item">
                <div class="tech-label">${item.label}:</div>
                <div class="tech-value">${item.value}</div>
            </div>
        `).join('');
    }

    // Utility Functions
    formatBytes(bytes) {
        if (bytes === 0 || bytes === 'Unknown') return bytes;
        
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
    }

    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showToast('Copied to clipboard!', 'success');
        }).catch(() => {
            this.showToast('Failed to copy to clipboard', 'error');
        });
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        const toastMessage = toast.querySelector('.toast-message');
        
        toastMessage.textContent = message;
        toast.className = `toast ${type}`;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    downloadJSON() {
        if (!this.currentData) return;
        
        const dataStr = JSON.stringify(this.currentData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `${this.currentData.name || 'torrent'}_metadata.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
        this.showToast('Metadata downloaded!', 'success');
    }

    clearResults() {
        // Reset form inputs
        document.getElementById('fileInput').value = '';
        document.getElementById('magnetInput').value = '';
        document.getElementById('hashInput').value = '';
        document.getElementById('fileInfo').style.display = 'none';
        document.getElementById('magnetCounter').textContent = '0 characters';
        document.getElementById('hashValidation').className = 'validation-indicator';
        
        // Hide results
        document.getElementById('resultsSection').style.display = 'none';
        
        // Reset data
        this.currentData = null;
        this.allFiles = [];
        this.filteredFiles = [];
        
        // Re-validate
        this.validateInput();
        
        // Scroll to top
        document.querySelector('.input-section').scrollIntoView({ behavior: 'smooth' });
        
        this.showToast('Results cleared', 'success');
    }
}

// Initialize the application
const torrentExtractor = new TorrentExtractor();